////
// The true purpose of this script to make it slightly easier for shrikers to waypoint items of interest as they're strafing the map. 
// Currently, when you're shriking, if you want to waypoint something you need to:
//   a) Go into CC
//   b) Right click on your object of interest
//   c) Select any of the options in the right click menu.
//   d) Exit out of CC
//   e) Type VCA or press the enter key to create a waypoint for that item.
//
// You need to do all of the above while avoiding anything that might want to shoot you down (or running into the ground). This can also be 
// useful for bomber crews as well.
// 
// Unfortunately, there's not good way to automate a) through d). T2 only provides useful information to the client after you've created the 
// potential waypoint action (option c). 
//
// The one thing that can be automated is e). It may not make much of an impact, but it's one less annoyance to worry about. The following
// are important to know regarding this script's functionality:
//   1) This script will *only* automatically accept waypoints that *you* create while you are *flying in a vehicle*.
//   2) This script will *not* automatically accept waypoints that you create while you are *not* in a vehicle.
//   3) This script will *not* automatically accept waypoints that anyone else creates under any other contexts. 
////


--Dependencies--
You must ensure you support the following dependencies:
1. UberGuy's Script Suite. 
   (I am unsure what supports this. This must include: a) Scripts tab in the browser, b) UberPrefs support. Both of the these are included in the all-in-one download.)


--Instructions--
1. Move AutoAcceptOwnTaskInVehicle.vl2 to your z_scripts or scripts folder
	